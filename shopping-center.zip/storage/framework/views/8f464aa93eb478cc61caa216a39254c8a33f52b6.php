

<?php $__env->startSection('content'); ?>
<section class="top">
      <div class="img-back-alt">
            <div class="flex container  py-8">
                  <div class="flex uppercase font-bold items-center text-white ml-auto my-auto">
                        <div>
                              <img src="<?php echo e(asset('assets/img/bi_arrow-left-circle.png')); ?>" alt="">
                        </div>
                        <a href="javascript:history.back()">
                              <div class="ml-1">
                                    <span>Voltar</span>
                              </div>
                        </a>
                  </div>
                  <div class="flex mx-auto te my-auto">
                       <a href="<?php echo e(url('/')); ?>"> <div class="img-logo-alt">
                              <img src="<?php echo e(asset('assets/img/logo.svg')); ?>" alt="">
                        </div></a>
                  </div>
            </div>
      </div>
</section>
<section class="container  my-4">
      <div class="grid grid-cols-2">
            <div class="flex slide-in-left justify-center items-center flex-col">
                  <div class="uppercase text-center font-bold text-2xl">
                        <h3><?php echo e($estabelecimento->name); ?></h3>
                  </div>
                  <div class="flex mt-4">
                      <a href="https://api.whatsapp.com/send?phone=55<?php echo e($estabelecimento->whatsapp); ?>&text=">  <div class="icons">
                              <img src="<?php echo e(asset('assets/img/whatsapp.png')); ?>" alt="">
                        </div></a>
                        <div class="icons">
                              <span class="iconify" data-inline="false" data-icon="eva:phone-call-outline"
                                    style="font-size: 40px;"></span>
                        </div>
                        <div class="icons tooltip">
                              <span class="iconify" data-inline="false" data-icon="ant-design:field-time-outlined"
                                    style="font-size: 46px;"></span>
                              <span class="tooltiptext">Horario de atendimento de seg a sex das 10:00 as 14:00</span>
                        </div>
                  </div>
            </div>
            <div class="logo-client rotate-in-diag-1 justify-self-center">
                  <img src="<?php echo e(asset('storage/logos/'. $estabelecimento->logo)); ?>" alt="">
            </div>
      </div>
</section>
<section class="my-5 products-grid">
      <div class="grid mx-4 gap-3 text-center uppercase font-bold font-xl grid-cols-2">
            <?php $__currentLoopData = $estabelecimento->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('produto/'. $produto->slug)); ?>">
                  <div class="img-cardapio">
                        <img src="<?php echo e(asset('storage/products/'. $produto->image)); ?>" alt="">
                        <p><?php echo e($produto->name); ?></p>
                  </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\shopping-center\resources\views/site/cardapio.blade.php ENDPATH**/ ?>