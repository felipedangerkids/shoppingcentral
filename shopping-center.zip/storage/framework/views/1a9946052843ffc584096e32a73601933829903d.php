

<?php $__env->startSection('content'); ?>
<?php
      $cores = array("bg-roxo-escuro", "bg-rosa", "bg-cinza", "bg-roxo", "bg-laranja");  
    
      ?>

    
<section>
      <div class="container pt-16  <?php echo $cores[array_rand($cores, 1)]; ?> ">
            <div class="grid grid-cols-2">
                  <div>
                        <div class="uppercase text-center font-bold text-2xl text-white">
                              <h3 class="mx-auto py-12  my-auto"> <?php echo e($estabelecimento->name); ?></h3>
                        </div>
                  </div>
                  <div>
                        <div class="logo-client rotate-in-diag-1 justify-self-center">
                              <img class="" src="<?php echo e(asset('storage/logos/'. $estabelecimento->logo)); ?>" alt="">
                        </div>
                  </div>
            </div>
            <div class="relative mx-5 top-8">
                  <div class="grid justify-center grid-cols-4">
                        <div >
                              <img class="w-3/4 mx-auto my-auto" src="<?php echo e(url('assets/img/ifood.svg')); ?>" alt="">
                        </div>
                        <div>
                              <img class="w-3/4 mx-auto my-auto" src="<?php echo e(url('assets/img/whatsapp.svg')); ?>" alt="">
                        </div>
                        <div>
                              <img class="w-3/4 mx-auto my-auto" src="<?php echo e(url('assets/img/central.svg')); ?>" alt="">
                        </div>
                        <div>
                              <img class="w-3/4 mx-auto my-auto" src="<?php echo e(url('assets/img/relogio.svg')); ?>" alt="">
                        </div>
                  </div>
            </div>
      </div>
</section>

<section>
      <div class="bg-black text-center  py-12 text-white">
            <p class="mx-8">Lorem ipsum dolor sit amet consectetur adipisicing elit. Error modi delectus facilis ea fugiat accusamus maiores hic, obcaecati eligendi ipsum assumenda suscipit culpa quis ad neque minus omnis saepe temporibus.</p>
      </div>
</section>

<section class="my-5 products-grid">
      <div class="grid mx-4 gap-3 text-center uppercase font-bold font-xl grid-cols-2">
            <?php $__currentLoopData = $estabelecimento->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('produto/'. $produto->slug)); ?>">
                  <div class="img-cardapio">
                        <img src="<?php echo e(asset('storage/products/'. $produto->image)); ?>" alt="">
                        <p><?php echo e($produto->name); ?></p>
                  </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\shopping-center\resources\views/site/estabelecimentos/cardapio.blade.php ENDPATH**/ ?>