

<?php $__env->startSection('content'); ?>

<section>
      <div class="home-base container grid grid-cols-3">
            <a href="<?php echo e(url('delivery')); ?>">
                  <div class="delivery flip-in-hor-top">
                        <img class="mx-auto my-auto w-1/4" src="<?php echo e(url('assets/img/delivery.svg')); ?>" alt="">
                        <h2>Delivery</h2>
                  </div>
            </a>
            <div class="gastronomia flip-in-hor-top">
                  <img class="mx-auto w-1/4" src="<?php echo e(url('assets/img/gastronomia.svg')); ?>" alt="">
                  <h2>Gastronomia</h2>
            </div>
            <div class="loja flip-in-hor-top">
                  <img class="mx-auto w-1/4" src="<?php echo e(url('assets/img/loja.svg')); ?>" alt="">
                  <h2>Lojas</h2>
            </div>

      </div>
</section>
<section>
      <div class="home-base-2 container grid grid-cols-3">
            <div class="col-span-2 slide-in-blurred-right">
                  <img class="object-cover banner" src="<?php echo e(url('assets/img/banner.jpg')); ?>" alt="">
            </div>
            <div class="flex flex-col slide-in-blurred-right">
                  <div class="estetica">
                        <img class="mx-auto w-1/4" src="<?php echo e(url('assets/img/estetica.svg')); ?>" alt="">
                        <h2>Estética</h2>
                  </div>

                  <div class="cadastro slide-in-blurred-right">
                        <img class="mx-auto w-1/4" src="<?php echo e(url('assets/img/cadastro.svg')); ?>" alt="">
                        <h2>Cadastro</h2>
                  </div>

            </div>

      </div>
</section>
<section>
      <div class="home-base-2 container grid grid-cols-3">
            <div class="mes slide-in-blurred-right flex items-center col-span-2">
                  <div class="mx-auto ">
                        <h2 class="font-2xl">Agenda do Mês</h2>
                  </div>
                  <div>
                        <img class="mx-auto w-1/4" src="<?php echo e(url('assets/img/mes.svg')); ?>" alt="">
                  </div>
            </div>
            <div class="pontos slide-in-blurred-right">
                  <img class="mx-auto w-1/4" src="<?php echo e(url('assets/img/pontos.svg')); ?>" alt="">
                  <h2>Programa de Pontos</h2>
            </div>
      </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\shopping-center\resources\views/site/index.blade.php ENDPATH**/ ?>