

<?php $__env->startSection('content'); ?>
<section>
      <div class="container delivery-base grid grid-cols-3">
            <div>
                  <a href="<?php echo e(url('delivery')); ?>">
                        <div class="delivery flip-in-hor-top bg-roxo">
                              <img class="mx-auto my-auto w-1/4" src="<?php echo e(url('assets/img/delivery.svg')); ?>" alt="">
                              <h2>Delivery</h2>
                        </div>
                  </a>
            </div>
            <div>
                  <a href="<?php echo e(url('delivery')); ?>">
                        <div class="flip-in-hor-top bg-cinza py-10">
                              <h2 class="mx-auto ">Delivery</h2>
                        </div>
                  </a>

            </div>
            <div>
                  <a href="<?php echo e(url('delivery')); ?>">
                        <div class="flip-in-hor-top bg-roxo-escuro py-10">
                              <h2 class="mx-auto">Delivery</h2>
                        </div>
                  </a>
            </div>
      </div>
</section>
<section>
      <?php
      $cores = array("bg-roxo-escuro", "bg-rosa", "bg-cinza", "bg-roxo", "bg-laranja");
      $count = 0;

      ?>

      <div class="container delivery-base-2 grid grid-cols-2">

            <?php $__currentLoopData = $estabelecimentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $est): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($est->delivery == 1): ?>
            <a href="<?php echo e(url('cardapio/'.$est->id)); ?>">
                  <div class="<?php echo e($cores[$count++]); ?>">
                        <h2><?php echo e($est->name); ?></h2>
                  </div>
            </a>
            <?php if($count == count($cores)): ?>
            <?php
            $count = 0;
            ?>
            <?php endif; ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\shopping-center\resources\views/site/estabelecimentos/delivery.blade.php ENDPATH**/ ?>