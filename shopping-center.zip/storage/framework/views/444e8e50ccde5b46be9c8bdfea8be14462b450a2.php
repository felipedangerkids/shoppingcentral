

<?php $__env->startSection('content'); ?>
<section class="top">

      <div class="img-back-alt">
            <div class="flex container  py-8">
                  <div class="flex uppercase font-bold items-center text-white ml-auto my-auto">
                        <div>
                              <img src="<?php echo e(asset('assets/img/bi_arrow-left-circle.png')); ?>" alt="">
                        </div>
                       <a href="javascript:history.back()"><div class="ml-1">
                              <span>Voltar</span>
                        </div></a>
                  </div>
                  <div class="flex mx-auto te my-auto">
                        <div class="img-logo-alt">
                              <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="">
                        </div>
                  </div>
            </div>
      </div>
      <div class="img-product">
            <img src="<?php echo e(asset('storage/products/'. $produto->image)); ?>" alt="">
      </div>
</section>
<section class="desc mt-3 mx-5">
      <div class="uppercase text-2xl font-bold">
            <h2><?php echo e($produto->name); ?></h2>
      </div>
      <div class="uppercase text-2xl font-bold">
            <h2><?php echo e('R$ '.number_format($produto->price, 2, ',', '.')); ?></h2>
      </div>
      <div class="text-base">
            <p><?php echo e($produto->desc); ?></p>
      </div>
      <div class="text-base">
            <p>Tempo de Entrega: <?php echo e($produto->time); ?></p>
      </div>
      <div class="my-4">
           <a href="https://api.whatsapp.com/send?phone=55<?php echo e($produto->estabelecimento->whatsapp); ?>&text=<?php echo e(Request::url()); ?>"> <button type="button"
                  class="focus:outline-none text-white text-xl py-2.5 px-10 rounded-md bg-green-500 hover:bg-green-600 hover:shadow-lg flex items-center">
                 <span class="mr-2"><i class="fab fa-whatsapp"></i></span> Fazer Pedido
            </button></a>
      </div>

</section>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\shopping-center\resources\views/site/produto.blade.php ENDPATH**/ ?>